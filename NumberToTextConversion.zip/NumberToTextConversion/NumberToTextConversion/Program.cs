﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumberToTextConversion
{
    class Program
    {
        const long finalRange = 999999999;
        static SortedDictionary<long, string> numberRange = new SortedDictionary<long, string>();
        static Program()
        {
            numberRange.Add(1000000, "million");
            numberRange.Add(1000, "thousand");
            numberRange.Add(100, "hundred");
        }
        static void Main(string[] args)
        {            
            bool isLong = false;
        convertNumber: Console.WriteLine("Enter Number to Text Conversion : ");
            long x = 0;
            try
            {
                isLong = true;
                x = Convert.ToInt64(Console.ReadLine());
                if (x > finalRange)
                {
                    Console.WriteLine("Input number should be <="+ finalRange);
                    goto convertNumber;
                }
            }
            catch
            {
                isLong = false;
            }

            if (isLong && x <= finalRange)
            {
                Console.WriteLine(NumberToWords(x));
            askAgain: Console.WriteLine("Do you Want to Continue (Y/N) : ");
                string strAnswer = Console.ReadLine();
                if (strAnswer.ToUpper() == "Y")
                    goto convertNumber;
                else if (strAnswer.ToUpper() == "N")
                    return;
                else
                {
                    Console.WriteLine("Invalid Input.....");
                    goto askAgain;
                }
            }
            else
            {
                Console.WriteLine("Invalid Number.....");
                goto convertNumber;
            }


        }
        
        public static string NumberToWords(long number)
        {
            if (number == 0)
                return "zero";

            if (number < 0)
                return "minus " + NumberToWords(Math.Abs(number));

            string convertedNumber = "";
            for (int k = numberRange.Keys.Count - 1; k >= 0; k--)
            {
                KeyValuePair<long, string> keyValPair = numberRange.ElementAt(k);
                if ((number / keyValPair.Key) > 0)
                {
                    convertedNumber += NumberToWords(number / keyValPair.Key) + " " + keyValPair.Value + " ";
                    number %= keyValPair.Key;
                }
            }

            if (number > 0)
            {
                if (convertedNumber != "")
                    convertedNumber += "and ";

                var ones = new[] { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen" };
                var tens = new[] { "zero", "ten", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety" };

                if (number < 20)
                    convertedNumber += ones[number];
                else
                {
                    convertedNumber += tens[number / 10];
                    if ((number % 10) > 0)
                        convertedNumber += " " + ones[number % 10];
                }
            }

            return convertedNumber;
        }
    }
}
